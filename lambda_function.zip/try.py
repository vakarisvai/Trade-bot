import requests
import pandas as pd
from datetime import datetime, timedelta

def fetch_stock_data(symbol: str, api_key: str) -> pd.DataFrame:
    """
    Fetches stock data from the Financial Modeling Prep API and returns it as a Pandas DataFrame.
    :param symbol: Stock symbol (e.g., 'AAPL' for Apple, 'AMZN' for Amazon).
    :param api_key: Your Financial Modeling Prep API key.
    :return: Pandas DataFrame with date as index and close price as column.
    """
    url = f'https://financialmodelingprep.com/api/v3/historical-price-full/{symbol}?apikey={api_key}'
    response = requests.get(url)
    
    if response.status_code == 200:
        data = response.json()['historical']
        df = pd.DataFrame(data)
        df['date'] = pd.to_datetime(df['date'])
        df.set_index('date', inplace=True)
        df = df[['close']]
        df.columns = ['Price']

        # df = df.loc[start_date:end_date]
        return df
    else:
        print(f"Failed to fetch data: {response.status_code} - {response.text}")
        return pd.DataFrame()

# Set your API key obtained from Financial Modeling Prep
api_key = '8ae7fc847def6d02c382175cc5341639'

# Set the stock symbol
symbol = 'AMZN'

# Fetch stock data
stock_data = fetch_stock_data(symbol, api_key)

print(stock_data)
